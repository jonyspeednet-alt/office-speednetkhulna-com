BEGIN;

ALTER TABLE internet_connection_registrations
  ADD COLUMN IF NOT EXISTS internet_user_id VARCHAR(120);

CREATE INDEX IF NOT EXISTS idx_icr_internet_user_id
  ON internet_connection_registrations(internet_user_id);

COMMIT;
