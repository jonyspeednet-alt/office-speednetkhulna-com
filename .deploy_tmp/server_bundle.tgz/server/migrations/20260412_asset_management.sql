BEGIN;

INSERT INTO permissions (code, legacy_key, name, description, module)
VALUES
  ('assets.view', 'p_assets_view', 'Assets View', 'View office assets and stock', 'asset_management'),
  ('assets.manage', 'p_assets_manage', 'Assets Manage', 'Manage assets, desks, offices, vendors and movements', 'asset_management')
ON CONFLICT (code) DO NOTHING;

CREATE TABLE IF NOT EXISTS asset_offices (
  id BIGSERIAL PRIMARY KEY,
  code VARCHAR(40) NOT NULL UNIQUE,
  name VARCHAR(150) NOT NULL,
  office_type VARCHAR(30) NOT NULL DEFAULT 'branch_office',
  address TEXT NULL,
  sort_order INTEGER NOT NULL DEFAULT 0,
  is_active BOOLEAN NOT NULL DEFAULT TRUE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS asset_desks (
  id BIGSERIAL PRIMARY KEY,
  office_id BIGINT NOT NULL REFERENCES asset_offices(id) ON DELETE CASCADE,
  desk_no VARCHAR(40) NOT NULL,
  desk_label VARCHAR(120) NULL,
  location_note TEXT NULL,
  is_active BOOLEAN NOT NULL DEFAULT TRUE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  UNIQUE(office_id, desk_no)
);

CREATE TABLE IF NOT EXISTS asset_categories (
  id BIGSERIAL PRIMARY KEY,
  name VARCHAR(120) NOT NULL UNIQUE,
  slug VARCHAR(140) NOT NULL UNIQUE,
  parent_id BIGINT NULL REFERENCES asset_categories(id) ON DELETE SET NULL,
  is_active BOOLEAN NOT NULL DEFAULT TRUE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS asset_vendors (
  id BIGSERIAL PRIMARY KEY,
  name VARCHAR(160) NOT NULL UNIQUE,
  contact_person VARCHAR(160) NULL,
  phone VARCHAR(40) NULL,
  email VARCHAR(160) NULL,
  warranty_contact TEXT NULL,
  notes TEXT NULL,
  is_active BOOLEAN NOT NULL DEFAULT TRUE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS assets (
  id BIGSERIAL PRIMARY KEY,
  asset_tag VARCHAR(80) NOT NULL UNIQUE,
  asset_name VARCHAR(180) NOT NULL,
  category_id BIGINT NULL REFERENCES asset_categories(id) ON DELETE SET NULL,
  vendor_id BIGINT NULL REFERENCES asset_vendors(id) ON DELETE SET NULL,
  office_id BIGINT NULL REFERENCES asset_offices(id) ON DELETE SET NULL,
  desk_id BIGINT NULL REFERENCES asset_desks(id) ON DELETE SET NULL,
  assigned_user_id INTEGER NULL REFERENCES users(id) ON DELETE SET NULL,
  brand VARCHAR(120) NULL,
  model VARCHAR(160) NULL,
  serial_number VARCHAR(160) NULL,
  purchase_date DATE NULL,
  purchase_price NUMERIC(12,2) NOT NULL DEFAULT 0,
  warranty_start_date DATE NULL,
  warranty_end_date DATE NULL,
  warranty_type VARCHAR(60) NULL,
  status VARCHAR(30) NOT NULL DEFAULT 'in_stock',
  condition VARCHAR(30) NOT NULL DEFAULT 'good',
  notes TEXT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS asset_movements (
  id BIGSERIAL PRIMARY KEY,
  asset_id BIGINT NOT NULL REFERENCES assets(id) ON DELETE CASCADE,
  from_office_id BIGINT NULL REFERENCES asset_offices(id) ON DELETE SET NULL,
  from_desk_id BIGINT NULL REFERENCES asset_desks(id) ON DELETE SET NULL,
  to_office_id BIGINT NULL REFERENCES asset_offices(id) ON DELETE SET NULL,
  to_desk_id BIGINT NULL REFERENCES asset_desks(id) ON DELETE SET NULL,
  moved_by INTEGER NULL REFERENCES users(id) ON DELETE SET NULL,
  reason TEXT NULL,
  moved_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_asset_offices_active ON asset_offices(is_active, sort_order);
CREATE INDEX IF NOT EXISTS idx_asset_desks_office ON asset_desks(office_id, is_active);
CREATE INDEX IF NOT EXISTS idx_asset_categories_active ON asset_categories(is_active, name);
CREATE INDEX IF NOT EXISTS idx_assets_office_desk ON assets(office_id, desk_id);
CREATE INDEX IF NOT EXISTS idx_assets_status ON assets(status);
CREATE INDEX IF NOT EXISTS idx_assets_category ON assets(category_id);
CREATE INDEX IF NOT EXISTS idx_asset_movements_asset ON asset_movements(asset_id, moved_at DESC);

INSERT INTO asset_offices (code, name, office_type, sort_order, is_active)
VALUES
  ('HQ', 'Head Office', 'head_office', 1, TRUE),
  ('BR-1', 'Branch Office 1', 'branch_office', 2, TRUE),
  ('BR-2', 'Branch Office 2', 'branch_office', 3, TRUE),
  ('BR-3', 'Branch Office 3', 'branch_office', 4, TRUE)
ON CONFLICT (code) DO NOTHING;

INSERT INTO asset_categories (name, slug)
VALUES
  ('PC', 'pc'),
  ('Monitor', 'monitor'),
  ('UPS', 'ups'),
  ('Router', 'router'),
  ('Switch', 'switch'),
  ('Printer', 'printer'),
  ('Accessory', 'accessory')
ON CONFLICT (slug) DO NOTHING;

INSERT INTO sidebar_menus (menu_name, link, icon, category, parent_id, permission_column, is_visible, sort_order)
VALUES
  ('Asset Management', '/asset-management', 'fa-boxes-stacked', 'Administration', NULL, 'p_assets_view', 1, 14)
ON CONFLICT (link) DO NOTHING;

UPDATE sidebar_menus
SET permission_column = 'p_assets_view',
    is_visible = 1,
    sort_order = 14
WHERE link = '/asset-management';

COMMIT;
