BEGIN;

ALTER TABLE internet_connection_registrations
  ADD COLUMN IF NOT EXISTS billing_cycle_day INTEGER,
  ADD COLUMN IF NOT EXISTS connection_expire_day INTEGER;

COMMIT;
