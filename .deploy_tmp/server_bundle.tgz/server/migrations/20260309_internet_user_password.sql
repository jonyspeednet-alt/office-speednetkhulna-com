BEGIN;

ALTER TABLE internet_connection_registrations
  ADD COLUMN IF NOT EXISTS internet_password VARCHAR(120);

CREATE INDEX IF NOT EXISTS idx_icr_internet_password
  ON internet_connection_registrations(internet_password);

COMMIT;
