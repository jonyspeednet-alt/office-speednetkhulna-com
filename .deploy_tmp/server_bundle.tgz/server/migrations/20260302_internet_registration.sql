BEGIN;

CREATE TABLE IF NOT EXISTS internet_connection_registrations (
  id BIGSERIAL PRIMARY KEY,
  applicant_name VARCHAR(150) NOT NULL,
  phone VARCHAR(30) NOT NULL,
  alternate_phone VARCHAR(30),
  email VARCHAR(120),
  area VARCHAR(120) NOT NULL,
  address TEXT NOT NULL,
  preferred_package_mbps INTEGER,
  connection_type VARCHAR(20) NOT NULL DEFAULT 'home',
  preferred_contact_time VARCHAR(50),
  notes TEXT,
  status VARCHAR(20) NOT NULL DEFAULT 'new',
  source VARCHAR(40) NOT NULL DEFAULT 'office_form',
  created_by INTEGER,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

ALTER TABLE internet_connection_registrations
  ADD COLUMN IF NOT EXISTS user_id_ip VARCHAR(80),
  ADD COLUMN IF NOT EXISTS application_date DATE,
  ADD COLUMN IF NOT EXISTS connection_date DATE,
  ADD COLUMN IF NOT EXISTS guardian_name VARCHAR(150),
  ADD COLUMN IF NOT EXISTS district VARCHAR(120),
  ADD COLUMN IF NOT EXISTS nid_number VARCHAR(50),
  ADD COLUMN IF NOT EXISTS date_of_birth DATE,
  ADD COLUMN IF NOT EXISTS occupation VARCHAR(120),
  ADD COLUMN IF NOT EXISTS reference_name VARCHAR(150),
  ADD COLUMN IF NOT EXISTS billing_contact_person VARCHAR(150),
  ADD COLUMN IF NOT EXISTS billing_address TEXT,
  ADD COLUMN IF NOT EXISTS billing_contact_number VARCHAR(30),
  ADD COLUMN IF NOT EXISTS installation_charge NUMERIC(10,2),
  ADD COLUMN IF NOT EXISTS package_rate NUMERIC(10,2),
  ADD COLUMN IF NOT EXISTS monthly_bill NUMERIC(10,2),
  ADD COLUMN IF NOT EXISTS billing_id VARCHAR(60),
  ADD COLUMN IF NOT EXISTS billing_date DATE,
  ADD COLUMN IF NOT EXISTS account_type VARCHAR(30),
  ADD COLUMN IF NOT EXISTS package_type VARCHAR(40),
  ADD COLUMN IF NOT EXISTS connectivity_type VARCHAR(30),
  ADD COLUMN IF NOT EXISTS connection_media_type VARCHAR(30),
  ADD COLUMN IF NOT EXISTS real_ip_required BOOLEAN,
  ADD COLUMN IF NOT EXISTS extra_hub BOOLEAN NOT NULL DEFAULT FALSE,
  ADD COLUMN IF NOT EXISTS free_id_pool_id BIGINT,
  ADD COLUMN IF NOT EXISTS branch_code VARCHAR(20),
  ADD COLUMN IF NOT EXISTS branch_name VARCHAR(100);

CREATE TABLE IF NOT EXISTS internet_branch_free_ids (
  id BIGSERIAL PRIMARY KEY,
  branch_code VARCHAR(20) NOT NULL,
  branch_name VARCHAR(100) NOT NULL,
  user_id_ip VARCHAR(80) NOT NULL,
  remarks VARCHAR(160),
  is_available BOOLEAN NOT NULL DEFAULT TRUE,
  allocated_registration_id BIGINT REFERENCES internet_connection_registrations(id) ON DELETE SET NULL,
  allocated_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  UNIQUE(branch_code, user_id_ip)
);

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1
    FROM pg_constraint
    WHERE conname = 'fk_icr_free_id_pool'
  ) THEN
    ALTER TABLE internet_connection_registrations
      ADD CONSTRAINT fk_icr_free_id_pool
      FOREIGN KEY (free_id_pool_id)
      REFERENCES internet_branch_free_ids(id)
      ON DELETE SET NULL;
  END IF;
END $$;

CREATE INDEX IF NOT EXISTS idx_icr_created_at ON internet_connection_registrations(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_icr_status ON internet_connection_registrations(status);
CREATE INDEX IF NOT EXISTS idx_icr_phone ON internet_connection_registrations(phone);
CREATE INDEX IF NOT EXISTS idx_ibfi_branch_available ON internet_branch_free_ids(branch_code, is_available);
CREATE INDEX IF NOT EXISTS idx_ibfi_user_id_ip ON internet_branch_free_ids(user_id_ip);

INSERT INTO internet_branch_free_ids (branch_code, branch_name, user_id_ip, remarks)
VALUES
  ('KHL-01', 'Khulna Main', 'KHLM-1001', 'Sample free ID'),
  ('KHL-01', 'Khulna Main', 'KHLM-1002', 'Sample free ID'),
  ('KHL-01', 'Khulna Main', 'KHLM-1003', 'Sample free ID'),
  ('KHL-02', 'Sonadanga', 'SND-2001', 'Sample free ID'),
  ('KHL-02', 'Sonadanga', 'SND-2002', 'Sample free ID'),
  ('KHL-02', 'Sonadanga', 'SND-2003', 'Sample free ID'),
  ('KHL-03', 'Daulatpur', 'DLP-3001', 'Sample free ID'),
  ('KHL-03', 'Daulatpur', 'DLP-3002', 'Sample free ID'),
  ('KHL-03', 'Daulatpur', 'DLP-3003', 'Sample free ID'),
  ('KHL-04', 'Rupsha', 'RPS-4001', 'Sample free ID'),
  ('KHL-04', 'Rupsha', 'RPS-4002', 'Sample free ID'),
  ('KHL-04', 'Rupsha', 'RPS-4003', 'Sample free ID')
ON CONFLICT (branch_code, user_id_ip) DO NOTHING;

INSERT INTO sidebar_menus (menu_name, link, icon, category, parent_id, permission_column, is_visible, sort_order)
VALUES
  ('Internet Registration', '/internet-registration', 'fa-wifi', 'Administration', NULL, '', 1, 12)
ON CONFLICT (link) DO NOTHING;

UPDATE sidebar_menus
SET permission_column = '',
    is_visible = 1,
    sort_order = 12
WHERE link = '/internet-registration';

INSERT INTO sidebar_menus (menu_name, link, icon, category, parent_id, permission_column, is_visible, sort_order)
VALUES
  ('Internet Free IDs', '/internet-registration/free-ids', 'fa-list-check', 'Administration', NULL, '', 1, 13)
ON CONFLICT (link) DO NOTHING;

COMMIT;
