BEGIN;

CREATE TABLE IF NOT EXISTS internet_packages (
  id BIGSERIAL PRIMARY KEY,
  name VARCHAR(80) NOT NULL,
  speed_mbps INTEGER NOT NULL,
  price_bdt NUMERIC(10,2) NOT NULL,
  vat_included BOOLEAN NOT NULL DEFAULT TRUE,
  is_active BOOLEAN NOT NULL DEFAULT TRUE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  UNIQUE (name)
);

ALTER TABLE internet_connection_registrations
  ADD COLUMN IF NOT EXISTS package_id BIGINT;

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1
    FROM pg_constraint
    WHERE conname = 'fk_icr_package'
  ) THEN
    ALTER TABLE internet_connection_registrations
      ADD CONSTRAINT fk_icr_package
      FOREIGN KEY (package_id)
      REFERENCES internet_packages(id)
      ON DELETE SET NULL;
  END IF;
END $$;

INSERT INTO internet_packages (name, speed_mbps, price_bdt, vat_included)
VALUES
  ('Swift 20', 20, 525, TRUE),
  ('Turbo 30', 30, 630, TRUE),
  ('Super 50', 50, 785, TRUE),
  ('NextGen 80', 80, 1050, TRUE),
  ('Hyper 100', 100, 1205, TRUE),
  ('Velocity 150', 150, 1730, TRUE)
ON CONFLICT (name) DO UPDATE
SET speed_mbps = EXCLUDED.speed_mbps,
    price_bdt = EXCLUDED.price_bdt,
    vat_included = EXCLUDED.vat_included,
    updated_at = NOW();

CREATE INDEX IF NOT EXISTS idx_internet_packages_active ON internet_packages(is_active, speed_mbps);

COMMIT;
