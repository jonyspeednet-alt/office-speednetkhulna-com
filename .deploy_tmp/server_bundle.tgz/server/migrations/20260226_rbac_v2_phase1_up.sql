-- RBAC V2 Phase 1 (Standard Foundation)
-- Safe to run multiple times (idempotent).
-- This migration does NOT remove legacy tables/columns yet.

BEGIN;

-- 1) Canonical permissions catalog
CREATE TABLE IF NOT EXISTS permissions (
  id BIGSERIAL PRIMARY KEY,
  code VARCHAR(120) NOT NULL UNIQUE,          -- canonical dotted key (e.g. leave.manage)
  legacy_key VARCHAR(120) UNIQUE,             -- optional legacy key (e.g. p_manage_leaves)
  name VARCHAR(160) NOT NULL,
  description TEXT,
  module VARCHAR(80) NOT NULL DEFAULT 'general',
  is_active BOOLEAN NOT NULL DEFAULT TRUE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- 2) Role -> Permission grants
CREATE TABLE IF NOT EXISTS role_permissions (
  role_id INTEGER NOT NULL REFERENCES roles(id) ON DELETE CASCADE,
  permission_id BIGINT NOT NULL REFERENCES permissions(id) ON DELETE CASCADE,
  granted_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  granted_by INTEGER NULL REFERENCES users(id) ON DELETE SET NULL,
  PRIMARY KEY (role_id, permission_id)
);

-- 3) User-level overrides (deny > allow > role grant)
CREATE TABLE IF NOT EXISTS user_permission_overrides (
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  permission_id BIGINT NOT NULL REFERENCES permissions(id) ON DELETE CASCADE,
  effect TEXT NOT NULL CHECK (effect IN ('allow', 'deny')),
  reason TEXT,
  expires_at TIMESTAMPTZ NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  created_by INTEGER NULL REFERENCES users(id) ON DELETE SET NULL,
  updated_by INTEGER NULL REFERENCES users(id) ON DELETE SET NULL,
  PRIMARY KEY (user_id, permission_id)
);

-- 4) Helpful indexes
CREATE INDEX IF NOT EXISTS idx_permissions_active ON permissions(is_active);
CREATE INDEX IF NOT EXISTS idx_permissions_module ON permissions(module);
CREATE INDEX IF NOT EXISTS idx_role_permissions_permission ON role_permissions(permission_id);
CREATE INDEX IF NOT EXISTS idx_user_perm_overrides_effect ON user_permission_overrides(effect);
CREATE INDEX IF NOT EXISTS idx_user_perm_overrides_expires_at ON user_permission_overrides(expires_at);

-- 5) Seed canonical permissions (+ legacy mapping)
INSERT INTO permissions (code, legacy_key, name, description, module)
VALUES
  ('system.all_access', 'all_access', 'All Access', 'Emergency full access permission', 'system'),
  ('users.manage', 'p_manage_users', 'Manage Users', 'Create/update users and staff settings', 'users'),
  ('permissions.manage', 'p_manage_permissions', 'Manage Permissions', 'Role and permission management access', 'rbac'),
  ('menus.manage', 'p_manage_menus', 'Manage Menus', 'Sidebar/menu configuration access', 'rbac'),
  ('leave.manage', 'p_manage_leaves', 'Manage Leaves', 'Review and approve/reject leave requests', 'leave'),
  ('leave.submit', 'p_leave_submission', 'Leave Submission', 'Submit leave requests', 'leave'),
  ('leave.apply', 'p_apply_leave', 'Apply Leave', 'Access apply leave page', 'leave'),
  ('leave.my', 'p_my_leaves', 'My Leaves', 'View own leave history', 'leave'),
  ('leave.approvals.view', 'p_approvals', 'Approvals View', 'View approval letter/resources', 'leave'),
  ('leave.entitlements.manage', 'p_entitlements', 'Manage Entitlements', 'Manage yearly leave entitlements', 'leave'),
  ('calendar.view', 'p_calendar', 'Leave Calendar', 'View leave calendar', 'leave'),
  ('reports.view', 'p_reports', 'Reports', 'View reports and analytics', 'reports'),
  ('notices.manage', 'p_notices', 'Notices', 'Manage notice ticker/system notices', 'system'),
  ('phone_directory.view', 'p_phone_directory', 'Phone Directory', 'View company phone directory', 'staff'),
  ('reseller.list', 'p_reseller_list', 'Reseller List', 'View reseller listing', 'reseller'),
  ('reseller.profile', 'p_reseller_profile', 'Reseller Profile', 'View reseller profile/details', 'reseller'),
  ('reseller.add', 'p_add_reseller', 'Add Reseller', 'Create reseller records', 'reseller'),
  ('reseller.requests.create', 'p_request_bw', 'Request Bandwidth', 'Create bandwidth requests', 'reseller'),
  ('reseller.requests.review', 'p_requests_admin', 'Requests Admin', 'Review bandwidth requests', 'reseller'),
  ('reseller.tasks.manage', 'p_tech_task', 'Tech Tasks', 'Manage technical task assignments', 'reseller'),
  ('reseller.status_noc.view', 'p_noc_view', 'Reseller NOC Status', 'View NOC status pages', 'reseller'),
  ('billing.logs.view', 'p_billing_logs', 'Billing Logs', 'View/add billing logs', 'billing'),
  ('billing.discount.add', 'p_add_discount', 'Add Discount', 'Add reseller discount ledger entry', 'billing'),
  ('billing.monthly_summary.view', 'p_monthly_summary', 'Monthly Summary', 'View monthly billing summary', 'billing'),
  ('billing.generate_bill', 'p_generate_bill', 'Generate Bill', 'Generate monthly bills', 'billing'),
  ('billing.invoice.view', 'p_invoice', 'Invoice', 'View invoice pages', 'billing'),
  ('billing.invoice.static_view', 'p_view_static_invoice', 'Static Invoice', 'View static invoice template', 'billing'),
  ('audit.system_logs.view', 'p_system_logs', 'System Logs', 'View audit + financial logs', 'audit'),
  ('procurement.manage', 'p_manage_procurement', 'Procurement', 'Manage procurement workflows', 'procurement')
ON CONFLICT (code) DO UPDATE
SET
  legacy_key = EXCLUDED.legacy_key,
  name = EXCLUDED.name,
  description = EXCLUDED.description,
  module = EXCLUDED.module,
  updated_at = NOW();

-- 6) Role JSONB -> role_permissions backfill (legacy compatibility)
WITH role_json_perm AS (
  SELECT
    r.id AS role_id,
    e.key AS perm_key
  FROM roles r
  CROSS JOIN LATERAL jsonb_each(COALESCE(r.permissions, '{}'::jsonb)) e
  WHERE (
    e.value = 'true'::jsonb
    OR e.value = '1'::jsonb
    OR lower(trim(both '"' FROM e.value::text)) IN ('true', '1')
  )
)
INSERT INTO role_permissions(role_id, permission_id)
SELECT DISTINCT
  rjp.role_id,
  p.id
FROM role_json_perm rjp
JOIN permissions p
  ON p.legacy_key = rjp.perm_key
  OR p.code = rjp.perm_key
ON CONFLICT (role_id, permission_id) DO NOTHING;

-- 7) all_access roles get all active permissions
INSERT INTO role_permissions(role_id, permission_id)
SELECT r.id, p.id
FROM roles r
JOIN permissions p ON p.is_active = TRUE
WHERE COALESCE((r.permissions ->> 'all_access')::boolean, FALSE) = TRUE
ON CONFLICT (role_id, permission_id) DO NOTHING;

-- 8) Legacy user_permissions -> user overrides (allow)
INSERT INTO user_permission_overrides(user_id, permission_id, effect, reason)
SELECT DISTINCT
  up.user_id,
  p.id,
  'allow',
  'Backfilled from legacy user_permissions table'
FROM user_permissions up
JOIN permissions p ON p.legacy_key = up.permission_key OR p.code = up.permission_key
ON CONFLICT (user_id, permission_id) DO UPDATE
SET
  effect = EXCLUDED.effect,
  reason = EXCLUDED.reason,
  updated_at = NOW();

-- 9) Effective permission view (deny > allow > role grant)
CREATE OR REPLACE VIEW v_effective_user_permissions AS
WITH role_grants AS (
  SELECT DISTINCT
    u.id AS user_id,
    p.code AS permission_code,
    TRUE AS granted
  FROM users u
  JOIN role_permissions rp ON rp.role_id = u.role_id
  JOIN permissions p ON p.id = rp.permission_id
  WHERE p.is_active = TRUE
),
overrides AS (
  SELECT
    upo.user_id,
    p.code AS permission_code,
    upo.effect,
    upo.expires_at
  FROM user_permission_overrides upo
  JOIN permissions p ON p.id = upo.permission_id
  WHERE p.is_active = TRUE
    AND (upo.expires_at IS NULL OR upo.expires_at > NOW())
)
SELECT
  base.user_id,
  base.permission_code,
  CASE
    WHEN EXISTS (
      SELECT 1 FROM overrides o
      WHERE o.user_id = base.user_id
        AND o.permission_code = base.permission_code
        AND o.effect = 'deny'
    ) THEN FALSE
    WHEN EXISTS (
      SELECT 1 FROM overrides o
      WHERE o.user_id = base.user_id
        AND o.permission_code = base.permission_code
        AND o.effect = 'allow'
    ) THEN TRUE
    WHEN EXISTS (
      SELECT 1 FROM role_grants rg
      WHERE rg.user_id = base.user_id
        AND rg.permission_code = base.permission_code
        AND rg.granted = TRUE
    ) THEN TRUE
    ELSE FALSE
  END AS is_allowed
FROM (
  SELECT u.id AS user_id, p.code AS permission_code
  FROM users u
  CROSS JOIN permissions p
  WHERE p.is_active = TRUE
) base;

COMMIT;
