BEGIN;

CREATE TABLE IF NOT EXISTS internet_branches (
  code VARCHAR(20) PRIMARY KEY,
  name VARCHAR(100) NOT NULL UNIQUE,
  is_active BOOLEAN NOT NULL DEFAULT TRUE,
  created_at TIMESTAMP NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMP NOT NULL DEFAULT NOW()
);

INSERT INTO internet_branches (code, name)
VALUES
  ('CORP', 'Corporate Office'),
  ('SHON', 'Shonadanga Office'),
  ('GOLL', 'Gollamari Office'),
  ('BOYR', 'Boyra Office')
ON CONFLICT (code) DO UPDATE
SET
  name = EXCLUDED.name,
  is_active = TRUE,
  updated_at = NOW();

GRANT SELECT ON TABLE public.internet_branches TO PUBLIC;

COMMIT;
