-- Office Work Tracker Table
-- Track daily office work entries

BEGIN;

-- Create office_work_entries table
CREATE TABLE IF NOT EXISTS office_work_entries (
  id BIGSERIAL PRIMARY KEY,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  task TEXT NOT NULL,
  category VARCHAR(50) NOT NULL DEFAULT 'general',
  priority VARCHAR(20) NOT NULL DEFAULT 'normal',
  work_date DATE,
  start_time TIME,
  end_time TIME,
  completed BOOLEAN NOT NULL DEFAULT FALSE,
  completed_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Backfill-safe schema upgrade for existing installations
ALTER TABLE office_work_entries ADD COLUMN IF NOT EXISTS work_date DATE;
ALTER TABLE office_work_entries ADD COLUMN IF NOT EXISTS start_time TIME;
ALTER TABLE office_work_entries ADD COLUMN IF NOT EXISTS end_time TIME;
ALTER TABLE office_work_entries ADD COLUMN IF NOT EXISTS completed_at TIMESTAMPTZ;

UPDATE office_work_entries
SET work_date = (created_at AT TIME ZONE 'Asia/Dhaka')::date
WHERE work_date IS NULL;

-- Create indexes
CREATE INDEX IF NOT EXISTS idx_office_work_user ON office_work_entries(user_id);
CREATE INDEX IF NOT EXISTS idx_office_work_created ON office_work_entries(created_at);
CREATE INDEX IF NOT EXISTS idx_office_work_completed ON office_work_entries(completed);

CREATE TABLE IF NOT EXISTS office_work_sessions (
  id BIGSERIAL PRIMARY KEY,
  entry_id BIGINT NOT NULL REFERENCES office_work_entries(id) ON DELETE CASCADE,
  user_id INTEGER NOT NULL,
  work_date DATE NOT NULL,
  start_time TIME NOT NULL,
  end_time TIME NOT NULL,
  notes TEXT,
  duration_minutes INTEGER NOT NULL CHECK (duration_minutes > 0),
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_office_work_sessions_entry ON office_work_sessions(entry_id);
CREATE INDEX IF NOT EXISTS idx_office_work_sessions_user_date ON office_work_sessions(user_id, work_date DESC);

-- Add permission for office work tracker
INSERT INTO permissions (code, legacy_key, name, description, module)
VALUES 
  ('office_work.manage', 'p_office_work', 'Office Work Tracker', 'Track and manage daily office work', 'staff')
ON CONFLICT (code) DO NOTHING;

-- Add sidebar menu for Office Work Tracker
INSERT INTO sidebar_menus (menu_name, link, icon, category, parent_id, permission_column, is_visible, sort_order)
VALUES 
  ('Office Work Tracker', '/office-work-tracker', 'fa-clipboard-list', 'Administration', NULL, '', 1, 11)
ON CONFLICT (link) DO NOTHING;

-- Ensure existing menu row is visible to all authenticated users
UPDATE sidebar_menus
SET permission_column = '',
    is_visible = 1
WHERE link = '/office-work-tracker'
  ;

COMMIT;
