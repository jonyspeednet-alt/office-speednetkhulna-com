-- RBAC V2 Phase 1 rollback
-- WARNING: This removes RBAC V2 structures created by phase1_up.
-- Legacy tables (roles.permissions JSONB, user_permissions) remain untouched.

BEGIN;

DROP VIEW IF EXISTS v_effective_user_permissions;

DROP TABLE IF EXISTS user_permission_overrides;
DROP TABLE IF EXISTS role_permissions;
DROP TABLE IF EXISTS permissions;

COMMIT;

