BEGIN;

ALTER TABLE billing_logs
  ADD COLUMN IF NOT EXISTS log_type VARCHAR(30);

UPDATE billing_logs
SET log_type = CASE
  WHEN COALESCE(transaction_amount, 0) > 0 THEN 'payment'
  ELSE 'adjustment'
END
WHERE log_type IS NULL;

CREATE INDEX IF NOT EXISTS idx_billing_logs_reseller_date
  ON billing_logs (reseller_id, effective_date);

CREATE INDEX IF NOT EXISTS idx_billing_logs_type_date
  ON billing_logs (log_type, effective_date);

CREATE TABLE IF NOT EXISTS billing_finalize_runs (
  id BIGSERIAL PRIMARY KEY,
  run_month DATE NOT NULL,
  started_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  ended_at TIMESTAMPTZ NULL,
  status VARCHAR(20) NOT NULL DEFAULT 'running',
  processed INTEGER NOT NULL DEFAULT 0,
  success INTEGER NOT NULL DEFAULT 0,
  failed INTEGER NOT NULL DEFAULT 0,
  initiator VARCHAR(80) NOT NULL DEFAULT 'system',
  source VARCHAR(40) NOT NULL DEFAULT 'scheduler',
  error_summary TEXT NULL
);

CREATE INDEX IF NOT EXISTS idx_billing_finalize_runs_month
  ON billing_finalize_runs (run_month DESC, started_at DESC);

CREATE TABLE IF NOT EXISTS billing_finalize_run_items (
  id BIGSERIAL PRIMARY KEY,
  run_id BIGINT NOT NULL REFERENCES billing_finalize_runs(id) ON DELETE CASCADE,
  reseller_id INTEGER NOT NULL,
  status VARCHAR(20) NOT NULL,
  bill_id BIGINT NULL,
  message TEXT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_billing_finalize_run_items_run
  ON billing_finalize_run_items (run_id, reseller_id);

INSERT INTO permissions (code, legacy_key, name, description, module)
VALUES ('billing.discount.add', 'p_add_discount', 'Add Discount', 'Add reseller discount ledger entry', 'billing')
ON CONFLICT (code) DO UPDATE
SET
  legacy_key = EXCLUDED.legacy_key,
  name = EXCLUDED.name,
  description = EXCLUDED.description,
  module = EXCLUDED.module,
  updated_at = NOW();

COMMIT;
