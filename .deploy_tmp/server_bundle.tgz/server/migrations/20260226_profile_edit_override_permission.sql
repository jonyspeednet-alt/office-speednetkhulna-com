-- Enable profile edit override permission key for selected roles.
-- Works when ALLOW_PROFILE_EDIT_OVERRIDE=true in .env

-- Grant to Admin role
UPDATE roles
SET permissions = jsonb_set(
  COALESCE(permissions, '{}'::jsonb),
  '{p_edit_any_profile}',
  'true'::jsonb,
  true
)
WHERE LOWER(name) = 'admin';

-- Grant to Super Admin role
UPDATE roles
SET permissions = jsonb_set(
  COALESCE(permissions, '{}'::jsonb),
  '{p_edit_any_profile}',
  'true'::jsonb,
  true
)
WHERE LOWER(name) IN ('super admin', 'superadmin');
