BEGIN;

CREATE TABLE IF NOT EXISTS brand_assets (
  id BIGSERIAL PRIMARY KEY,
  asset_key VARCHAR(100) NOT NULL UNIQUE,
  asset_path TEXT NOT NULL,
  asset_type VARCHAR(50) NOT NULL DEFAULT 'image',
  is_active BOOLEAN NOT NULL DEFAULT TRUE,
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

INSERT INTO brand_assets (asset_key, asset_path, asset_type, is_active, updated_at)
VALUES ('internet_registration_logo', '/src/assets/speednet-application-logo.png', 'image', TRUE, NOW())
ON CONFLICT (asset_key) DO UPDATE
SET asset_path = EXCLUDED.asset_path,
    asset_type = EXCLUDED.asset_type,
    is_active = EXCLUDED.is_active,
    updated_at = NOW();

COMMIT;
