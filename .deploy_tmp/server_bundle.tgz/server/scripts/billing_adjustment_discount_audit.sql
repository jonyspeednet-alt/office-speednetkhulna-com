-- Billing Audit: monthly_bills.adjustment vs billing_logs.discount
-- PostgreSQL compatible
--
-- Usage example:
--   psql "$DATABASE_URL" -f server/scripts/billing_adjustment_discount_audit.sql
--
-- This report is safe for databases where billing_logs.log_type may not exist.

-- 1) Month + reseller level comparison (last 12 months)
WITH bill_adj AS (
  SELECT
    mb.reseller_id,
    TO_CHAR(mb.bill_month, 'YYYY-MM') AS ym,
    COALESCE(SUM(mb.adjustment), 0)::numeric(18,2) AS adjustment_total
  FROM monthly_bills mb
  WHERE mb.bill_month >= date_trunc('month', CURRENT_DATE) - interval '11 months'
  GROUP BY mb.reseller_id, TO_CHAR(mb.bill_month, 'YYYY-MM')
),
discount_log AS (
  SELECT
    bl.reseller_id,
    TO_CHAR(COALESCE(bl.effective_date, bl.created_at), 'YYYY-MM') AS ym,
    COALESCE(SUM(bl.transaction_amount), 0)::numeric(18,2) AS discount_total
  FROM billing_logs bl
  WHERE COALESCE(
      to_jsonb(bl)->>'log_type',
      CASE
        WHEN LOWER(COALESCE(bl.change_desc, '')) LIKE 'discount:%' THEN 'discount'
        WHEN COALESCE(bl.transaction_amount, 0) > 0 THEN 'payment'
        ELSE 'adjustment'
      END
    ) = 'discount'
    AND COALESCE(bl.effective_date, bl.created_at) >= date_trunc('month', CURRENT_DATE) - interval '11 months'
  GROUP BY bl.reseller_id, TO_CHAR(COALESCE(bl.effective_date, bl.created_at), 'YYYY-MM')
),
merged AS (
  SELECT
    COALESCE(a.reseller_id, d.reseller_id) AS reseller_id,
    COALESCE(a.ym, d.ym) AS ym,
    COALESCE(a.adjustment_total, 0)::numeric(18,2) AS adjustment_total,
    COALESCE(d.discount_total, 0)::numeric(18,2) AS discount_total
  FROM bill_adj a
  FULL OUTER JOIN discount_log d
    ON a.reseller_id = d.reseller_id
   AND a.ym = d.ym
)
SELECT
  m.reseller_id,
  r.reseller_name,
  m.ym AS bill_month,
  m.adjustment_total,
  m.discount_total,
  (m.adjustment_total - m.discount_total)::numeric(18,2) AS diff_amount,
  CASE
    WHEN ABS(m.adjustment_total - m.discount_total) < 0.01 THEN 'MATCH'
    WHEN m.adjustment_total <> 0 AND m.discount_total = 0 THEN 'ADJUSTMENT_ONLY'
    WHEN m.adjustment_total = 0 AND m.discount_total <> 0 THEN 'DISCOUNT_ONLY'
    ELSE 'MIXED_DIFF'
  END AS status
FROM merged m
LEFT JOIN resellers r ON r.id = m.reseller_id
ORDER BY
  ABS(m.adjustment_total - m.discount_total) DESC,
  m.ym DESC,
  m.reseller_id ASC;

-- 2) High-level monthly totals summary (last 12 months)
WITH monthly_adj AS (
  SELECT
    TO_CHAR(mb.bill_month, 'YYYY-MM') AS ym,
    COALESCE(SUM(mb.adjustment), 0)::numeric(18,2) AS adjustment_total
  FROM monthly_bills mb
  WHERE mb.bill_month >= date_trunc('month', CURRENT_DATE) - interval '11 months'
  GROUP BY TO_CHAR(mb.bill_month, 'YYYY-MM')
),
monthly_discount AS (
  SELECT
    TO_CHAR(COALESCE(bl.effective_date, bl.created_at), 'YYYY-MM') AS ym,
    COALESCE(SUM(bl.transaction_amount), 0)::numeric(18,2) AS discount_total
  FROM billing_logs bl
  WHERE COALESCE(
      to_jsonb(bl)->>'log_type',
      CASE
        WHEN LOWER(COALESCE(bl.change_desc, '')) LIKE 'discount:%' THEN 'discount'
        WHEN COALESCE(bl.transaction_amount, 0) > 0 THEN 'payment'
        ELSE 'adjustment'
      END
    ) = 'discount'
    AND COALESCE(bl.effective_date, bl.created_at) >= date_trunc('month', CURRENT_DATE) - interval '11 months'
  GROUP BY TO_CHAR(COALESCE(bl.effective_date, bl.created_at), 'YYYY-MM')
)
SELECT
  COALESCE(a.ym, d.ym) AS ym,
  COALESCE(a.adjustment_total, 0)::numeric(18,2) AS adjustment_total,
  COALESCE(d.discount_total, 0)::numeric(18,2) AS discount_total,
  (COALESCE(a.adjustment_total, 0) - COALESCE(d.discount_total, 0))::numeric(18,2) AS diff_amount
FROM monthly_adj a
FULL OUTER JOIN monthly_discount d ON d.ym = a.ym
ORDER BY ym DESC;
